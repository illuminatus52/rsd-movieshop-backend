package com.rsd_movieshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RsdMovieshopApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(RsdMovieshopApplication.class, args);
	}
	
}
